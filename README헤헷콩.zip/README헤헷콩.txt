dev/web_Service.py 에서 실습 가능하고 나머지는 모두 시행착오를 겪은 것들입니다.

https://huggingface.co/google/gemma-2-2b-it
해당 사이트에 들어가서 

Access Gemma on Hugging Face 하시고 
Access Tokens에서 Create new token 해서 Value 따로 저장하시면 됩니다.