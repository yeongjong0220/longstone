import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import mediapipe as mp

# MediaPipe 포즈 연결선 가져오기
mp_pose = mp.solutions.pose
CONNECTIONS = mp_pose.POSE_CONNECTIONS

# 1. CSV 데이터 로드
try:
    df = pd.read_csv('C:\\capstone_PC\\my_venv\\min\\min_dev_park\\easy_motion.csv')
    print(f"✅ easy_motion.csv 로드 완료! (총 {len(df)}프레임)")
except FileNotFoundError:
    print("❌ easy_motion.csv 파일을 찾을 수 없습니다.")
    exit()

# 2. 3D 플롯 설정
fig = plt.figure(figsize=(8, 8))
ax = fig.add_subplot(111, projection='3d')

def update(frame_idx):
    ax.clear()
    
    # 그래프 축 범위 및 이름 설정 (사람 스케일에 맞게 조절)
    ax.set_xlim([-1.0, 1.0])
    ax.set_ylim([-1.0, 1.0])
    ax.set_zlim([-1.5, 0.5]) # 높이
    ax.set_xlabel('X (가로)')
    ax.set_ylabel('Z_MediaPipe (깊이)')
    ax.set_zlabel('-Y_MediaPipe (높이)')
    ax.set_title(f"프레임: {frame_idx} / {len(df)}")
    
    # 현재 프레임 데이터 꺼내오기
    row = df.iloc[frame_idx]
    
    # 모든 랜드마크 좌표를 3D 공간에 올바르게 변환하여 저장
    # **[핵심 변환법]**: 누워있는 문제를 해결하기 위해 Y와 Z축을 교환/반전합니다.
    # 3D의 Z축(높이) = MediaPipe의 -Y축 (위로 갈수록 양수)
    # 3D의 Y축(깊이) = MediaPipe의 Z축 
    pts = {}
    for lm in mp_pose.PoseLandmark:
        x_val = row.get(f"{lm.name}_x", 0)
        y_val = row.get(f"{lm.name}_y", 0)
        z_val = row.get(f"{lm.name}_z", 0)
        
        # 축 변환
        plot_x = x_val
        plot_y = z_val 
        plot_z = -y_val 
        
        pts[lm.value] = (plot_x, plot_y, plot_z)
        # 점 렌더링
        ax.scatter(plot_x, plot_y, plot_z, color='red', s=10)
        
    # 연결선 렌더링
    for connection in CONNECTIONS:
        start_idx = connection[0]
        end_idx = connection[1]
        
        if start_idx in pts and end_idx in pts:
            start_p = pts[start_idx]
            end_p = pts[end_idx]
            
            xs = [start_p[0], end_p[0]]
            ys = [start_p[1], end_p[1]]
            zs = [start_p[2], end_p[2]]
            
            ax.plot(xs, ys, zs, color='blue', linewidth=2)

# 3. 애니메이션 실행 (밀리초 간격 interval 설정)
ani = animation.FuncAnimation(fig, update, frames=len(df), interval=50, repeat=True)

# 한글 폰트 적용 (에러 방지)
plt.rcParams['font.family'] = 'Malgun Gothic'
plt.rcParams['axes.unicode_minus'] = False

print("프로그램 창을 통해 3D 스켈레톤 애니메이션을 확인하세요!")
plt.show()
