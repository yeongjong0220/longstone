import os
import sys
import collections
import cv2
import mediapipe as mp
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

# ==========================================
# [설정] 사용자 환경 설정 변수
# ==========================================
# 1. 사용할 정답 CSV 파일 경로 (사용자님 환경에 맞게 이름을 수정해주세요)
EXPERT_CSV_PATH = r"C:\capstone_PC\my_venv\min\min_dev_park\keypoints_프레임자름_238_350_필라테스_가산_A_Mat_The Seal_고급_actorP075_20220930_12.47.57.csv"
# EXPERT_CSV_PATH = "C:\capstone_PC\my_venv\min\min_dev_park\easy_motion.csv"

# ==========================================
# 1. Feature Engineering (관절 각도 추출기)
# ==========================================
class FeatureExtractor:
    def __init__(self):
        self.mp_pose = mp.solutions.pose
        # 핵심 관절 10개 이름
        self.angle_names = [
            "L_Elbow", "R_Elbow", "L_Armpit", "R_Armpit",
            "L_Hip", "R_Hip", "L_Knee", "R_Knee",
            "Neck_Spine", "Knee_Spread"
        ]

    def _get_pt(self, landmarks, idx):
        """MediaPipe 랜드마크 배열에서 x,y,z 좌표를 Numpy 배열로 추출"""
        pt = landmarks[idx]
        return np.array([pt.x, pt.y, pt.z])

    def calculate_angle_3d(self, a, b, c):
        """세 점(a, b, c)간의 3D 공간 각도(b가 꼭짓점)를 계산"""
        ba = a - b
        bc = c - b
        cosine_angle = np.dot(ba, bc) / (np.linalg.norm(ba) * np.linalg.norm(bc) + 1e-8)
        return np.degrees(np.arccos(np.clip(cosine_angle, -1.0, 1.0)))

    def extract_from_landmarks(self, landmarks):
        """
        한 프레임의 MediaPipe landmark 객체에서 10개의 핵심 각도를 추출하여 Vector(List)로 반환.
        """
        pl = self.mp_pose.PoseLandmark
        
        # 기본 랜드마크 추출
        nose = self._get_pt(landmarks, pl.NOSE)
        l_sh = self._get_pt(landmarks, pl.LEFT_SHOULDER)
        r_sh = self._get_pt(landmarks, pl.RIGHT_SHOULDER)
        l_el = self._get_pt(landmarks, pl.LEFT_ELBOW)
        r_el = self._get_pt(landmarks, pl.RIGHT_ELBOW)
        l_wr = self._get_pt(landmarks, pl.LEFT_WRIST)
        r_wr = self._get_pt(landmarks, pl.RIGHT_WRIST)
        l_hp = self._get_pt(landmarks, pl.LEFT_HIP)
        r_hp = self._get_pt(landmarks, pl.RIGHT_HIP)
        l_kn = self._get_pt(landmarks, pl.LEFT_KNEE)
        r_kn = self._get_pt(landmarks, pl.RIGHT_KNEE)
        l_an = self._get_pt(landmarks, pl.LEFT_ANKLE)
        r_an = self._get_pt(landmarks, pl.RIGHT_ANKLE)

        # 가상(Center) 랜드마크 계산
        mid_sh = (l_sh + r_sh) / 2.0
        mid_hp = (l_hp + r_hp) / 2.0

        # 10개 핵심 각도 계산
        angles = np.zeros(10)
        angles[0] = self.calculate_angle_3d(l_sh, l_el, l_wr)   # L_Elbow
        angles[1] = self.calculate_angle_3d(r_sh, r_el, r_wr)   # R_Elbow
        angles[2] = self.calculate_angle_3d(l_hp, l_sh, l_el)   # L_Armpit
        angles[3] = self.calculate_angle_3d(r_hp, r_sh, r_el)   # R_Armpit
        angles[4] = self.calculate_angle_3d(l_sh, l_hp, l_kn)   # L_Hip
        angles[5] = self.calculate_angle_3d(r_sh, r_hp, r_kn)   # R_Hip
        angles[6] = self.calculate_angle_3d(l_hp, l_kn, l_an)   # L_Knee
        angles[7] = self.calculate_angle_3d(r_hp, r_kn, r_an)   # R_Knee
        angles[8] = self.calculate_angle_3d(nose, mid_sh, mid_hp) # Neck_Spine
        angles[9] = self.calculate_angle_3d(l_kn, mid_hp, r_kn)   # Knee_Spread (Mid_Hip을 꼭짓점으로 양 무릎이 벌어진 각도)

        return angles
        
    def extract_from_csv(self, csv_path):
        """
        CSV 파일에서 좌표를 읽어와 프레임별로 10개 각도의 Sequence Matrix를 반환.
        (MediaPipe 컬럼 규격: 'LEFT_SHOULDER_x', 'LEFT_SHOULDER_y', 'LEFT_SHOULDER_z' 라고 가정)
        """
        try:
            df = pd.read_csv(csv_path)
            print(f"✅ 정답 CSV 로드 완료: {csv_path} (총 {len(df)}프레임)")
        except Exception as e:
            print(f"❌ CSV 로드 실패. 파일명이나 경로를 확인해주세요: {e}")
            sys.exit()

        is_mediapipe = 'LEFT_SHOULDER_x' in df.columns
        
        seq = []
        for i, row in df.iterrows():
            try:
                def get_p(name):
                    return np.array([row[f'{name}_x'], row[f'{name}_y'], row[f'{name}_z']])
                
                if is_mediapipe:
                    nose = get_p('NOSE')
                    l_sh, r_sh = get_p('LEFT_SHOULDER'), get_p('RIGHT_SHOULDER')
                    l_el, r_el = get_p('LEFT_ELBOW'), get_p('RIGHT_ELBOW')
                    l_wr, r_wr = get_p('LEFT_WRIST'), get_p('RIGHT_WRIST')
                    l_hp, r_hp = get_p('LEFT_HIP'), get_p('RIGHT_HIP')
                    l_kn, r_kn = get_p('LEFT_KNEE'), get_p('RIGHT_KNEE')
                    l_an, r_an = get_p('LEFT_ANKLE'), get_p('RIGHT_ANKLE')
                    mid_sh = (l_sh + r_sh) / 2.0
                    mid_hp = (l_hp + r_hp) / 2.0
                else:
                    # 원본 15개 관절 (Head, Neck, LShoulder, LKnee 등)
                    nose = get_p('Head')
                    l_sh, r_sh = get_p('LShoulder'), get_p('RShoulder')
                    l_el, r_el = get_p('LElbow'), get_p('RElbow')
                    l_wr, r_wr = get_p('LWrist'), get_p('RWrist')
                    l_hp, r_hp = get_p('LHip'), get_p('RHip')
                    l_kn, r_kn = get_p('LKnee'), get_p('Rknee') # 원본 CSV가 소문자 k를 씀
                    l_an, r_an = get_p('LAnkle'), get_p('RAnkle')
                    mid_sh = get_p('Neck')
                    mid_hp = get_p('Hip')


                angles = np.zeros(10)
                angles[0] = self.calculate_angle_3d(l_sh, l_el, l_wr)
                angles[1] = self.calculate_angle_3d(r_sh, r_el, r_wr)
                angles[2] = self.calculate_angle_3d(l_hp, l_sh, l_el)
                angles[3] = self.calculate_angle_3d(r_hp, r_sh, r_el)
                angles[4] = self.calculate_angle_3d(l_sh, l_hp, l_kn)
                angles[5] = self.calculate_angle_3d(r_sh, r_hp, r_kn)
                angles[6] = self.calculate_angle_3d(l_hp, l_kn, l_an)
                angles[7] = self.calculate_angle_3d(r_hp, r_kn, r_an)
                angles[8] = self.calculate_angle_3d(nose, mid_sh, mid_hp)
                angles[9] = self.calculate_angle_3d(l_kn, mid_hp, r_kn)
                seq.append(angles)
            except KeyError as e:
                print(f"❌ CSV 컬럼 에러: {e}. 'LEFT_SHOULDER_x' 같은 형태로 x,y,z 컬럼이 전부 있는지 확인하세요.")
                sys.exit()

        return np.array(seq) # Shape: (N, 10)


# ==========================================
# 2. Windowed Search Logic (정답 데이터 기반 동기화)
# ==========================================
class MotionSynchronizer:
    def __init__(self, expert_sequence, window_size=15):
        self.expert_seq = expert_sequence
        self.total_frames = len(expert_sequence)
        self.window_size = window_size
        self.current_idx = 0

    def get_best_match(self, user_vec):
        """
        현재 찾은 인덱스(current_idx)부터 +window_size 까지 중, 가장 MAE(Mean Absolute Error) 가 낮은 인덱스를 반환.
        """
        # 탐색 윈도우 설정
        start_idx = self.current_idx
        end_idx = min(self.current_idx + self.window_size, self.total_frames)
        
        if start_idx >= self.total_frames - 1:
            return self.total_frames - 1, 0, "Finish"

        window_seq = self.expert_seq[start_idx:end_idx]
        
        # 윈도우 내의 각 프레임과 유클리드/MAE 오차(절댓값 차이 평균) 계산
        errors = np.mean(np.abs(window_seq - user_vec), axis=1)
        
        min_error_idx_in_window = np.argmin(errors)
        min_mae = errors[min_error_idx_in_window]
        
        # 매치된 프레임으로 현재 위치 전진
        best_idx_global = start_idx + min_error_idx_in_window
        self.current_idx = best_idx_global
        
        # [수정] V4 (관대한 평가 모드) 
        # 등급 판정 (Great: < 15도, Good: < 25도, Normal: < 35도, Bad: >= 35도)
        if min_mae < 15: grade = "Great"
        elif min_mae < 25: grade = "Good"
        elif min_mae < 35: grade = "Normal"
        else: grade = "Bad"
            
        return best_idx_global, min_mae, grade


# ==========================================
# 3. Session Analyzer (사후 리포트 및 시각화)
# ==========================================
class SessionAnalyzer:
    def __init__(self, angle_names):
        self.angle_names = angle_names
        self.history_user = []
        self.history_expert = []
        self.history_mae = []

    def log_frame(self, user_vec, expert_vec, mae):
        self.history_user.append(user_vec)
        self.history_expert.append(expert_vec)
        self.history_mae.append(mae)

    def generate_report(self):
        if len(self.history_user) == 0:
            print("💡 수집된 데이터가 부족하여 리포트를 생성할 수 없습니다.")
            return

        user_seq = np.array(self.history_user)
        ref_seq = np.array(self.history_expert)
        
        # 프레임 별 10개 관절의 절대 오차들의 평균 (최종 점수 파악용)
        # 모양: (10,) -> 각 부위별 평균 오차
        abs_errors_per_joint = np.mean(np.abs(user_seq - ref_seq), axis=0)
        
        # [수정] V4 (관대한 평가 모드)
        # 오차(도) 1도당 1점이 아니라, 0.4점만 감점하도록 하여 후하게 산출 (100점 - (평균오차 * 0.4))
        overall_accuracy = max(0, 100 - (np.mean(abs_errors_per_joint) * 0.4))

        print("\n" + "="*50)
        print(f"📊 [AI 필라테스 사후 분석 리포트]")
        print(f"🏆 전체 일치도 점수: {overall_accuracy:.1f} / 100 (관대함 모드 적용됨)")
        print("="*50)
        for i, name in enumerate(self.angle_names):
            print(f" - {name:>12}: 평균 오차 {abs_errors_per_joint[i]:.1f}도")
        print("="*50)
        print("💡 저장된 Radar Chart(radar_report.png)와 팝업창을 확인하세요.")

        # ==================
        # Radar Chart 생성
        # ==================
        # 차트 생성을 위해 한글 폰트 설정(만약 깨진다면 폰트 경로 변경 필요)
        plt.rcParams['font.family'] = 'Malgun Gothic'
        plt.rcParams['axes.unicode_minus'] = False

        labels = self.angle_names
        num_vars = len(labels)
        
        # Radar 차트는 각도가 원형이므로 리스트 끝에 첫 요소를 추가해 닫힌 다각형을 그림
        angles = np.linspace(0, 2 * np.pi, num_vars, endpoint=False).tolist()
        angles += angles[:1]
        
        errors = abs_errors_per_joint.tolist()
        errors += errors[:1]

        fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))
        
        ax.fill(angles, errors, color='red', alpha=0.25)
        ax.plot(angles, errors, color='red', linewidth=2, marker='o', label='평균 오차 (도)')
        
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(labels, fontsize=11)
        ax.set_title("부위별 평균 오차 레이더 차트\n(작을수록 정답에 가까움)", size=15, weight='bold', pad=20)
        ax.legend(loc='upper right', bbox_to_anchor=(1.1, 1.1))
        
        # 1. 파일로 저장
        save_path = "radar_report_v4.png"
        plt.savefig(save_path, bbox_inches='tight', dpi=300)
        print(f"✅ 오프라인 리포트 이미지 저장 완료: {os.path.abspath(save_path)}")
        
        # 2. 팝업창 띄우기 (실행 흐름은 차트 창을 닫아야 종료됨)
        plt.show()

# ==========================================
# 메인 실행부 (실시간 웹캠 + 정답 매칭 알고리즘)
# ==========================================
def main():
    extractor = FeatureExtractor()
    
    # 1. 정답 시퀀스 파일 로드
    # 아직 CSV 파일이 준비 안 된 경우 임시 테스트로 랜덤 데이터를 쓰도록 방어코드 작성
    if os.path.exists(EXPERT_CSV_PATH):
        expert_seq = extractor.extract_from_csv(EXPERT_CSV_PATH)
    else:
        print(f"⚠️ [경고] {EXPERT_CSV_PATH} 파일을 찾을 수 없습니다.")
        print("⚠️ 에러 방지를 위해 가상의 빈 정답 시퀀스(112프레임)를 생성하여 데모 모드로 돌아갑니다.")
        expert_seq = np.zeros((112, 10)) + 90.0 # 모든 각도 90도 임시 배정

    synchronizer = MotionSynchronizer(expert_seq, window_size=15)
    analyzer = SessionAnalyzer(extractor.angle_names)

    # 2. 웹캠 및 MediaPipe 초기화
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    if not cap.isOpened():
        cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)
    if not cap.isOpened():
        cap = cv2.VideoCapture(0)

    mp_pose = mp.solutions.pose
    pose = mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5)
    mp_drawing = mp.solutions.drawing_utils

    print("\n🎥 관대한 평가의 데이터 기반 실시간 코칭 시작. ('q'를 누르면 종료 및 리포트 표시)")
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret: break

        frame = cv2.flip(frame, 1)
        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = pose.process(image)
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

        grade = "-"
        mae_dist = 0
        expert_idx = 0

        if results.pose_landmarks:
            mp_drawing.draw_landmarks(image, results.pose_landmarks, mp_pose.POSE_CONNECTIONS)
            
            try:
                # 3. 사용자 프레임에서 벡터(10개 각도) 추출
                user_vec = extractor.extract_from_landmarks(results.pose_landmarks.landmark)
                
                # 4. 정답 데이터와 동기화(Windowed Match) 및 등급 판별
                expert_idx, mae_dist, grade = synchronizer.get_best_match(user_vec)
                
                # 분석을 위해 히스토리 기록
                analyzer.log_frame(user_vec, expert_seq[expert_idx], mae_dist)

                # 화면 색상 설정 (Great=Green, Good=Blue, Normal=Yellow, Bad=Red)
                if grade == "Great": color = (0, 255, 0)
                elif grade == "Good": color = (255, 165, 0) # 파랑/하늘 느낌 (OpenCV는 BGR)
                elif grade == "Normal": color = (0, 255, 255)
                else: color = (0, 0, 255)

                # V4 관대한 버전 표시
                cv2.putText(image, f"Grade: {grade} (MAE: {mae_dist:.1f}) [V4 Lenient]", (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
                
                progress = int((expert_idx / synchronizer.total_frames) * 100)
                cv2.putText(image, f"Prog: {progress}% [Frame: {expert_idx}/{synchronizer.total_frames}]", (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                
            except Exception as e:
                print(f"프레임 처리 중 내부 오류 발생: {e}")

        cv2.imshow('Hybrid Data-Driven AI Coach', image)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

    # 5. 종료 후 리포트 및 레이더 차트 생성 (팝업 & 이미지 저장)
    analyzer.generate_report()

if __name__ == "__main__":
    main()
