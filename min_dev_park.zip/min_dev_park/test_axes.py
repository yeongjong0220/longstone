import pandas as pd
df = pd.read_csv(r'C:\capstone_PC\my_venv\min\keypoints_필라테스_가산_A_Mat_The Seal_고급_actorP075_20220930_12.47.57.csv')
row = df.iloc[0]
pts = ['Head', 'Neck', 'LShoulder', 'RShoulder', 'LHip', 'RHip', 'LKnee', 'Rknee', 'LAnkle', 'RAnkle']
print("Landmark positions for Frame 0 (X, Y, Z)")
for p in pts:
    x = row[p+'_x']
    y = row[p+'_y']
    z = row[p+'_z']
    print(f'{p:>10}: X={x:>5.2f}, Y={y:>5.2f}, Z={z:>5.2f}')
