import csv
import math
import mediapipe as mp

mp_pose = mp.solutions.pose
landmarks = [lm.name for lm in mp_pose.PoseLandmark]

# We'll generate 60 frames of a person doing a simple "hands up and down" while standing.
# Base standing position (roughly mapping the human body):
# Nose: 0, 0.1, 0
# Shoulders: L(-0.15, 0.2, 0), R(0.15, 0.2, 0)
# Hips: L(-0.1, 0.5, 0), R(0.1, 0.5, 0)
# Knees: L(-0.1, 0.8, 0), R(0.1, 0.8, 0)
# Ankles: L(-0.1, 1.0, 0), R(0.1, 1.0, 0)
# Elbows: L(-0.25, 0.4, 0), R(0.25, 0.4, 0) # slightly bent initially
# Wrists: L(-0.3, 0.6, 0), R(0.3, 0.6, 0) # hands down

def get_base_pose():
    pose = {}
    for lm in landmarks:
        pose[f"{lm}_x"] = 0.0
        pose[f"{lm}_y"] = 0.0
        pose[f"{lm}_z"] = 0.0

    pose["NOSE_x"], pose["NOSE_y"], pose["NOSE_z"] = 0.0, 0.1, 0.0
    pose["LEFT_SHOULDER_x"], pose["LEFT_SHOULDER_y"], pose["LEFT_SHOULDER_z"] = -0.15, 0.2, 0.0
    pose["RIGHT_SHOULDER_x"], pose["RIGHT_SHOULDER_y"], pose["RIGHT_SHOULDER_z"] = 0.15, 0.2, 0.0
    pose["LEFT_HIP_x"], pose["LEFT_HIP_y"], pose["LEFT_HIP_z"] = -0.1, 0.5, 0.0
    pose["RIGHT_HIP_x"], pose["RIGHT_HIP_y"], pose["RIGHT_HIP_z"] = 0.1, 0.5, 0.0
    pose["LEFT_KNEE_x"], pose["LEFT_KNEE_y"], pose["LEFT_KNEE_z"] = -0.1, 0.8, 0.0
    pose["RIGHT_KNEE_x"], pose["RIGHT_KNEE_y"], pose["RIGHT_KNEE_z"] = 0.1, 0.8, 0.0
    pose["LEFT_ANKLE_x"], pose["LEFT_ANKLE_y"], pose["LEFT_ANKLE_z"] = -0.1, 1.0, 0.0
    pose["RIGHT_ANKLE_x"], pose["RIGHT_ANKLE_y"], pose["RIGHT_ANKLE_z"] = 0.1, 1.0, 0.0
    
    pose["LEFT_ELBOW_x"], pose["LEFT_ELBOW_y"], pose["LEFT_ELBOW_z"] = -0.25, 0.4, 0.0
    pose["RIGHT_ELBOW_x"], pose["RIGHT_ELBOW_y"], pose["RIGHT_ELBOW_z"] = 0.25, 0.4, 0.0
    pose["LEFT_WRIST_x"], pose["LEFT_WRIST_y"], pose["LEFT_WRIST_z"] = -0.3, 0.6, 0.0
    pose["RIGHT_WRIST_x"], pose["RIGHT_WRIST_y"], pose["RIGHT_WRIST_z"] = 0.3, 0.6, 0.0

    return pose

frames = []
total_frames = 60
for i in range(total_frames):
    pose = get_base_pose()
    
    # We will animate the arms raising up and going down using a sine wave
    # Arm rotation angle from 0 to 180 degrees (0 to pi)
    progress = i / total_frames
    angle = math.sin(progress * math.pi) * math.pi # 0 -> pi -> 0
    
    # Rotate arm around shoulder
    # When angle=0, arms are down. When angle=pi, arms are up (y moves negative, meaning up in image space)
    # L_SHOULDER: -0.15, 0.2
    # L_ELBOW length = 0.25
    elbow_len = 0.25
    wrist_len = 0.25
    
    # Left arm:
    pose["LEFT_ELBOW_x"] = pose["LEFT_SHOULDER_x"] - elbow_len * math.sin(angle)
    pose["LEFT_ELBOW_y"] = pose["LEFT_SHOULDER_y"] + elbow_len * math.cos(angle)
    pose["LEFT_WRIST_x"] = pose["LEFT_ELBOW_x"] - wrist_len * math.sin(angle)
    pose["LEFT_WRIST_y"] = pose["LEFT_ELBOW_y"] + wrist_len * math.cos(angle)

    # Right arm:
    pose["RIGHT_ELBOW_x"] = pose["RIGHT_SHOULDER_x"] + elbow_len * math.sin(angle)
    pose["RIGHT_ELBOW_y"] = pose["RIGHT_SHOULDER_y"] + elbow_len * math.cos(angle)
    pose["RIGHT_WRIST_x"] = pose["RIGHT_ELBOW_x"] + wrist_len * math.sin(angle)
    pose["RIGHT_WRIST_y"] = pose["RIGHT_ELBOW_y"] + wrist_len * math.cos(angle)
    
    frames.append(pose)

headers = frames[0].keys()
with open("easy_motion.csv", "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=headers)
    writer.writeheader()
    writer.writerows(frames)
    
print("easy_motion.csv 생성 완료")
